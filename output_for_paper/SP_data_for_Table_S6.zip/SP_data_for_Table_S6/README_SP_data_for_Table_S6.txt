README for file SP_data_for_Table_S6.zip

This zip file contains SigProfilerExtractor results on data sets SBS_set1 and indel_set1.

The results are reported in Supplementary Table S6.

Table S6 reports the results of SigProfilerExtractor at values of K (number of extracted
signatures) other than the value selected automatically (the "Suggested_Solution").
We normally delete these results from the SigProfilerExtractor output to save space, 
but for Table S6 we need some of these results. 

Therefore, this zip file provides results for some other values of K.

Results are in directories
{SBS_set1,indel_set1}/raw_results/SigProfilerExtractor.results/\
  Realistic/seed.<seed>/{SBS96,ID83}/All_Solutions/<subdirs for selected K>)
